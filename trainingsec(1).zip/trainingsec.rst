.. code:: ipython3

    import tensorflow as tf
    from tensorflow.keras import models, layers
    import matplotlib.pyplot as plt
    
    IMAGE_SIZE = 256
    BATCH_SIZE = 32
    CHANNELS = 3
    EPOCHS = 40
    
    dataset = tf.keras.preprocessing.image_dataset_from_directory(
        "PlantVillage",
        shuffle=True,
        image_size=(IMAGE_SIZE, IMAGE_SIZE),
        batch_size=BATCH_SIZE
    )
    
    class_names = dataset.class_names
    
    train_size = 0.8
    len(dataset) * train_size
    
    train_ds = dataset.take(516)
    len(train_ds)
    
    temp_test_ds = dataset.skip(516)
    len(temp_test_ds)
    
    val_size = 0.1
    len(dataset) * val_size
    
    val_ds = temp_test_ds.take(64)
    len(val_ds)
    
    test_ds = temp_test_ds.skip(64)
    len(test_ds)
    
    def get_dataset_partitions_tf(ds, train_split=0.8, val_split=0.1, test_split=0.1, shuffle=True, shufflesize=10000):
        ds_size = len(ds)
        if shuffle:
            ds = ds.shuffle(shufflesize, seed=12)  # Fixed the variable name here
        train_size = int(train_split * ds_size)
        val_size = int(val_split * ds_size)
       
        train_ds = ds.take(train_size)
        
        val_ds = ds.skip(train_size).take(val_size)
        test_ds = ds.skip(train_size + val_size)  # Adjusted to skip both train and validation data
        return train_ds, val_ds, test_ds
    
    train_ds, val_ds, test_ds = get_dataset_partitions_tf(dataset)
    
    train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=tf.data.AUTOTUNE)
    val_ds = val_ds.cache().shuffle(1000).prefetch(buffer_size=tf.data.AUTOTUNE)
    test_ds = test_ds.cache().shuffle(1000).prefetch(buffer_size=tf.data.AUTOTUNE)
    
    resize_and_rescale = tf.keras.Sequential([
        layers.Resizing(IMAGE_SIZE, IMAGE_SIZE),
        layers.Rescaling(1.0 / 255)
    ])
    
    data_augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal_and_vertical"),
        layers.RandomRotation(0.2),
    ])
    
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense
    
    n_classes = 15
    # Define the image size and number of channels
    IMAGE_SIZE = 256
    CHANNELS = 3
    
    # Define the rescaling factor
    rescale_factor = 1.0 / 255.0
    
    # Define the model
    model = Sequential([
        Input(shape=(IMAGE_SIZE, IMAGE_SIZE, CHANNELS)),  # Input layer with specified shape
        Conv2D(32, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, kernel_size=(3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, kernel_size=(3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(64, activation='relu'),
        Dense(n_classes, activation='softmax')
    ])
    
    # Compile the model
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    
    # Print model summary
    model.summary()
    
    # Train the model
    history = model.fit(
        train_ds.cache().shuffle(1000).prefetch(buffer_size=tf.data.AUTOTUNE),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        verbose=1,
        validation_data=val_ds.cache().shuffle(1000).prefetch(buffer_size=tf.data.AUTOTUNE)
    )
    
    # Evaluate the model
    score = model.evaluate(test_ds)
    


.. parsed-literal::

    Found 20638 files belonging to 15 classes.
    


.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold">Model: "sequential_2"</span>
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace">┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┓
    ┃<span style="font-weight: bold"> Layer (type)                         </span>┃<span style="font-weight: bold"> Output Shape                </span>┃<span style="font-weight: bold">         Param # </span>┃
    ┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━┩
    │ conv2d (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                      │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">254</span>, <span style="color: #00af00; text-decoration-color: #00af00">254</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)        │             <span style="color: #00af00; text-decoration-color: #00af00">896</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)         │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">127</span>, <span style="color: #00af00; text-decoration-color: #00af00">127</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)        │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ conv2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">125</span>, <span style="color: #00af00; text-decoration-color: #00af00">125</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)        │          <span style="color: #00af00; text-decoration-color: #00af00">18,496</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">62</span>, <span style="color: #00af00; text-decoration-color: #00af00">62</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ conv2d_2 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">60</span>, <span style="color: #00af00; text-decoration-color: #00af00">60</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │          <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d_2 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">30</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ conv2d_3 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">28</span>, <span style="color: #00af00; text-decoration-color: #00af00">28</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │          <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d_3 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ conv2d_4 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">12</span>, <span style="color: #00af00; text-decoration-color: #00af00">12</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)          │          <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d_4 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">6</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)            │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ conv2d_5 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">4</span>, <span style="color: #00af00; text-decoration-color: #00af00">4</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)            │          <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ max_pooling2d_5 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">2</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)            │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ flatten (<span style="color: #0087ff; text-decoration-color: #0087ff">Flatten</span>)                    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)                 │               <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ dense (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                        │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)                  │          <span style="color: #00af00; text-decoration-color: #00af00">16,448</span> │
    ├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
    │ dense_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                      │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">15</span>)                  │             <span style="color: #00af00; text-decoration-color: #00af00">975</span> │
    └──────────────────────────────────────┴─────────────────────────────┴─────────────────┘
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Total params: </span><span style="color: #00af00; text-decoration-color: #00af00">184,527</span> (720.81 KB)
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">184,527</span> (720.81 KB)
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Non-trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">0</span> (0.00 B)
    </pre>
    


.. parsed-literal::

    Epoch 1/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1757s[0m 3s/step - accuracy: 0.3552 - loss: 2.4108 - val_accuracy: 0.7056 - val_loss: 0.9259
    Epoch 2/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1581s[0m 3s/step - accuracy: 0.7369 - loss: 0.7935 - val_accuracy: 0.7671 - val_loss: 0.7147
    Epoch 3/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1713s[0m 3s/step - accuracy: 0.8035 - loss: 0.5839 - val_accuracy: 0.8604 - val_loss: 0.4145
    Epoch 4/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1337s[0m 3s/step - accuracy: 0.8563 - loss: 0.4245 - val_accuracy: 0.8843 - val_loss: 0.3416
    Epoch 5/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1382s[0m 3s/step - accuracy: 0.8827 - loss: 0.3456 - val_accuracy: 0.8809 - val_loss: 0.3505
    Epoch 6/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1198s[0m 2s/step - accuracy: 0.9033 - loss: 0.2829 - val_accuracy: 0.8906 - val_loss: 0.3299
    Epoch 7/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1090s[0m 2s/step - accuracy: 0.9144 - loss: 0.2427 - val_accuracy: 0.9165 - val_loss: 0.2637
    Epoch 8/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1055s[0m 2s/step - accuracy: 0.9212 - loss: 0.2308 - val_accuracy: 0.9292 - val_loss: 0.2194
    Epoch 9/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1281s[0m 2s/step - accuracy: 0.9351 - loss: 0.1859 - val_accuracy: 0.9028 - val_loss: 0.3089
    Epoch 10/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1611s[0m 3s/step - accuracy: 0.9394 - loss: 0.1858 - val_accuracy: 0.9424 - val_loss: 0.1879
    Epoch 11/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1610s[0m 3s/step - accuracy: 0.9456 - loss: 0.1570 - val_accuracy: 0.8315 - val_loss: 0.5245
    Epoch 12/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1551s[0m 3s/step - accuracy: 0.9418 - loss: 0.1718 - val_accuracy: 0.9565 - val_loss: 0.1409
    Epoch 13/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1569s[0m 3s/step - accuracy: 0.9581 - loss: 0.1296 - val_accuracy: 0.9165 - val_loss: 0.2513
    Epoch 14/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1010s[0m 2s/step - accuracy: 0.9418 - loss: 0.1703 - val_accuracy: 0.9136 - val_loss: 0.2892
    Epoch 15/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m528s[0m 1s/step - accuracy: 0.9572 - loss: 0.1295 - val_accuracy: 0.9453 - val_loss: 0.1764
    Epoch 16/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m512s[0m 992ms/step - accuracy: 0.9630 - loss: 0.1188 - val_accuracy: 0.9478 - val_loss: 0.1719
    Epoch 17/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m543s[0m 1s/step - accuracy: 0.9524 - loss: 0.1490 - val_accuracy: 0.8867 - val_loss: 0.3785
    Epoch 18/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m609s[0m 1s/step - accuracy: 0.9510 - loss: 0.1383 - val_accuracy: 0.9443 - val_loss: 0.2036
    Epoch 19/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m596s[0m 1s/step - accuracy: 0.9648 - loss: 0.1109 - val_accuracy: 0.9604 - val_loss: 0.1467
    Epoch 20/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m600s[0m 1s/step - accuracy: 0.9642 - loss: 0.1154 - val_accuracy: 0.9438 - val_loss: 0.2039
    Epoch 21/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m605s[0m 1s/step - accuracy: 0.9541 - loss: 0.1360 - val_accuracy: 0.9512 - val_loss: 0.1564
    Epoch 22/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m601s[0m 1s/step - accuracy: 0.9739 - loss: 0.0802 - val_accuracy: 0.9209 - val_loss: 0.2565
    Epoch 23/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m589s[0m 1s/step - accuracy: 0.9627 - loss: 0.1092 - val_accuracy: 0.9590 - val_loss: 0.1505
    Epoch 24/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m569s[0m 1s/step - accuracy: 0.9725 - loss: 0.0833 - val_accuracy: 0.9658 - val_loss: 0.1195
    Epoch 25/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m615s[0m 1s/step - accuracy: 0.9719 - loss: 0.0854 - val_accuracy: 0.9478 - val_loss: 0.2058
    Epoch 26/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m600s[0m 1s/step - accuracy: 0.9603 - loss: 0.1260 - val_accuracy: 0.9580 - val_loss: 0.1585
    Epoch 27/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m601s[0m 1s/step - accuracy: 0.9707 - loss: 0.0961 - val_accuracy: 0.9507 - val_loss: 0.1863
    Epoch 28/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m598s[0m 1s/step - accuracy: 0.9626 - loss: 0.1229 - val_accuracy: 0.9160 - val_loss: 0.3265
    Epoch 29/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1557s[0m 3s/step - accuracy: 0.9750 - loss: 0.0731 - val_accuracy: 0.9390 - val_loss: 0.2419
    Epoch 30/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1428s[0m 3s/step - accuracy: 0.9688 - loss: 0.1013 - val_accuracy: 0.9453 - val_loss: 0.1791
    Epoch 31/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m502s[0m 973ms/step - accuracy: 0.9709 - loss: 0.0973 - val_accuracy: 0.9419 - val_loss: 0.2245
    Epoch 32/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m833s[0m 2s/step - accuracy: 0.9707 - loss: 0.0923 - val_accuracy: 0.9727 - val_loss: 0.1257
    Epoch 33/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m513s[0m 993ms/step - accuracy: 0.9744 - loss: 0.0872 - val_accuracy: 0.9741 - val_loss: 0.1273
    Epoch 34/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m514s[0m 995ms/step - accuracy: 0.9774 - loss: 0.0732 - val_accuracy: 0.9590 - val_loss: 0.1457
    Epoch 35/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m498s[0m 965ms/step - accuracy: 0.9748 - loss: 0.0796 - val_accuracy: 0.9644 - val_loss: 0.1289
    Epoch 36/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m511s[0m 990ms/step - accuracy: 0.9694 - loss: 0.0938 - val_accuracy: 0.9639 - val_loss: 0.1373
    Epoch 37/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m501s[0m 970ms/step - accuracy: 0.9745 - loss: 0.0726 - val_accuracy: 0.9424 - val_loss: 0.2032
    Epoch 38/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m514s[0m 995ms/step - accuracy: 0.9639 - loss: 0.1165 - val_accuracy: 0.9580 - val_loss: 0.1557
    Epoch 39/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m507s[0m 982ms/step - accuracy: 0.9740 - loss: 0.0857 - val_accuracy: 0.9717 - val_loss: 0.1023
    Epoch 40/40
    [1m516/516[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m505s[0m 980ms/step - accuracy: 0.9778 - loss: 0.0664 - val_accuracy: 0.9551 - val_loss: 0.1797
    [1m65/65[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m210s[0m 920ms/step - accuracy: 0.9731 - loss: 0.0893
    

.. code:: ipython3

    history




.. parsed-literal::

    <keras.src.callbacks.history.History at 0x24f9f1b3d90>



.. code:: ipython3

    history.params




.. parsed-literal::

    {'verbose': 1, 'epochs': 40, 'steps': 516}



.. code:: ipython3

    history.history.keys()




.. parsed-literal::

    dict_keys(['accuracy', 'loss', 'val_accuracy', 'val_loss'])



.. code:: ipython3

    acc = history.history['accuracy']
    val_acc = history.history['accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

.. code:: ipython3

    len(acc)




.. parsed-literal::

    40



.. code:: ipython3

    import matplotlib.pyplot as plt
    
    plt.figure(figsize=(8, 4))
    plt.plot(range(EPOCHS), acc, label='Training Accuracy', color='blue')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title('Training Accuracy')
    plt.legend()
    plt.grid(True)
    plt.show()
    
    plt.figure(figsize=(8, 4))
    plt.plot(range(EPOCHS), val_acc, label='Validation Accuracy', color='red')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title('Validation Accuracy')
    plt.legend()
    plt.grid(True)
    plt.show()
    



.. image:: output_6_0.png



.. image:: output_6_1.png


.. code:: ipython3

    import matplotlib.pyplot as plt
    
    plt.figure(figsize=(8, 4))
    
    # Plot training loss
    plt.plot(range(EPOCHS), loss, label='Training Loss', color='blue')
    
    # Plot validation loss
    plt.plot(range(EPOCHS), val_loss, label='Validation Loss', color='red')
    
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss')
    plt.legend()
    plt.grid(True)
    plt.show()
    



.. image:: output_7_0.png


.. code:: ipython3

    import numpy as np
    import matplotlib.pyplot as plt
    
    image, label = next(iter(test_ds))
    
    plt.imshow(image[0].numpy().astype('uint8'))
    plt.show()
    
    print("Actual label:", class_names[label[0].numpy()])
    
    prediction = model.predict(image)
    
    predicted_probabilities = prediction[0]
    
    print("Predicted probabilities:", predicted_probabilities)
    



.. image:: output_8_0.png


.. parsed-literal::

    Actual label: Tomato__Target_Spot
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    Predicted probabilities: [1.7452953e-07 4.2517889e-11 4.2178453e-12 2.3849415e-11 4.7031552e-13
     7.6958059e-08 1.3967436e-05 1.0625347e-07 4.7693813e-09 2.3179207e-05
     4.6357567e-08 9.9996138e-01 1.9930698e-11 9.5604948e-13 1.0525345e-06]
    

.. code:: ipython3

    import numpy as np
    
    for images_batch, labels_batch in test_ds.take(1):
        first_image = images_batch[0].numpy().astype('uint8')
        first_label = labels_batch[0].numpy()
        
        plt.imshow(first_image)
        plt.show()
        
        print("Actual label:", class_names[first_label])
        
        batch_prediction = model.predict(images_batch)
        
        print("Predicted label:", class_names[np.argmax(batch_prediction[0])])
    



.. image:: output_9_0.png


.. parsed-literal::

    Actual label: Potato___Early_blight
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 808ms/step
    Predicted label: Potato___Early_blight
    

.. code:: ipython3

    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn.metrics import f1_score
    
    # Collect all predicted labels for the test set
    predicted_labels = []
    true_labels = []
    
    for images_batch, labels_batch in test_ds:
        predictions = model.predict(images_batch)
        predicted_labels.extend(np.argmax(predictions, axis=1))
        true_labels.extend(labels_batch.numpy())
    
    # Calculate F1 score
    f1 = f1_score(true_labels, predicted_labels, average='weighted')
    print("F1 score:", f1)
    


.. parsed-literal::

    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 806ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 663ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 777ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 814ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 867ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 791ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 823ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 766ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 806ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 712ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 928ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 785ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 815ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 813ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 789ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 767ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 871ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 846ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 776ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 776ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 738ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 780ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 883ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 772ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 728ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 776ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 802ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 789ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 783ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 726ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 716ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 927ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 818ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 777ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 804ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 713ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 840ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 833ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 881ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 803ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 820ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 788ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 730ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 910ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 802ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 857ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 775ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 814ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 525ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 506ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 920ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 901ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 969ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 944ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 891ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 952ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 868ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 920ms/step
    F1 score: 0.9721214022040059
    


.. code:: ipython3

    import numpy as np
    
    # Initialize variables to count TP, FP, TN, FN
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    
    # Iterate over the test dataset to make predictions
    for images_batch, labels_batch in test_ds:
        predictions_batch = model.predict(images_batch)
        predicted_labels_batch = np.argmax(predictions_batch, axis=1)
        
        # Update TP, FP, TN, FN counts
        for predicted_label, true_label in zip(predicted_labels_batch, labels_batch):
            if predicted_label == true_label:
                if predicted_label == 1:  # Positive class
                    TP += 1
                else:  # Negative class
                    TN += 1
            else:
                if predicted_label == 1:  # Positive class
                    FP += 1
                else:  # Negative class
                    FN += 1
    
    # Calculate metrics
    accuracy = (TP + TN) / (TP + FN + TN + FP)
    precision = TP / (TP + FP)
    recall = TP / (TP + FN)
    f1_score = 2 * (precision * recall) / (precision + recall)
    sensitivity = recall
    specificity = TN / (FP + TN)
    false_positive_rate = 1 - specificity
    
    # Print the calculated metrics
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall (Sensitivity):", recall)
    print("F1 Score:", f1_score)
    print("Specificity:", specificity)
    print("False Positive Rate:", false_positive_rate)
    


.. parsed-literal::

    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 833ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 769ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 778ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 873ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 911ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 914ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 831ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 722ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 832ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 787ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 723ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 771ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 802ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 769ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 897ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 818ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 661ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 835ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 834ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 378ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 887ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 791ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step   
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 789ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 866ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 981ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 996ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 532ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 987ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 954ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 2s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 859ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 872ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 485ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 416ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 456ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 500ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 447ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 536ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 2s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 749ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 801ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 935ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 791ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 860ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 997ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 973ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 880ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 887ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 729ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 983ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 871ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 1s/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 980ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 894ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m1s[0m 845ms/step
    Accuracy: 0.9721153846153846
    Precision: 0.9863013698630136
    Recall (Sensitivity): 0.72
    F1 Score: 0.8323699421965317
    Specificity: 0.9989361702127659
    False Positive Rate: 0.0010638297872340718
    

.. code:: ipython3

    plt.figure(figsize=(20,20))
    for images, labels in test_ds.take(1):
        for i in range(6):
            ax = plt.subplot(3, 2, i+1)
            plt.imshow(images[i].numpy().astype("uint8"))
            predictions = model.predict(np.expand_dims(images[i], axis=0))
            predicted_class = class_names[np.argmax(predictions)]
            confidence = np.max(predictions) * 100
            actual_class = class_names[labels[i]]
            plt.title(f"Actual: {actual_class},\nPredicted: {predicted_class}.\nConfidence: {confidence:.2f}%")
            plt.axis("off")
        plt.show()
    


.. parsed-literal::

    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 306ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 79ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 70ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 73ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 107ms/step
    [1m1/1[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 80ms/step
    


.. image:: output_13_1.png


.. code:: ipython3

    import os
    
    # Directory path
    directory = r"C:\Users\Abi Karimireddy\Downloads\deep learning\Training\final"
    
    # Create directory if it doesn't exist
    if not os.path.exists(directory):
        os.makedirs(directory)
    
    # Now save your model
    model_version = 1
    model.save(f"{directory}{model_version}.keras")
    

.. code:: ipython3

    import os
    
    # Directory containing the model files
    directory = r"C:\Users\Abi Karimireddy\Downloads\deep learning\Training\final"
    
    # Get a list of all files in the directory
    files = os.listdir(directory)
    
    # Extract the numeric part of each filename
    file_numbers = [int(i.split('.')[0]) for i in files if i.split('.')[0].isdigit()]
    
    # Find the maximum version number and increment by 1
    max_version = max(file_numbers) + 1 if file_numbers else 1
    
    # Save the model with the incremented version number
    model.save(f"{directory}/{max_version}.keras")
    

